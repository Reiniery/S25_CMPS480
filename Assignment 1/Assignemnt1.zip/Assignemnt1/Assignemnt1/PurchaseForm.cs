﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Assignemnt1
{
    public static class TransactionManager
    {
        public static List<decimal> Transactions = new List<decimal>();
    }
    public partial class PurchaseForm : Form
    {
        public PurchaseForm()
        {
            InitializeComponent();
            DisplayAvailableItems();
        }
        private List<Item> cart = new List<Item>();
        
        
        private void PurchaseForm_Load(object sender, EventArgs e)
        {

        }
        private void DisplayAvailableItems()
        {
            lstProducts.Items.Clear();
            foreach (var item in InventoryManager.Inventory)
            {
                lstProducts.Items.Add($"{item.Name} - ${item.Price}");
            }
        }
        private void ClearCart()
        {
            cart.Clear();
            lstCart.Items.Clear();
        }
        private void ReturnToMainMenu()
        {
            this.Close();
        }
        private void CalculateTotal()
        {
            decimal total = cart.Sum(item => item.Price);
            MessageBox.Show($"Your Total is ${total} \nThank you for shopping at Target! {TransactionManager.Transactions.Count()} ");

            TransactionManager.Transactions.Add(total);

            ClearCart();
            ReturnToMainMenu();
        }

        private void addToCart()
        {
            if (lstProducts.SelectedItem != null && int.TryParse(txtQuantity.Text, out int quantity) && quantity > 0)
            {
                string selectedItemName = lstProducts.SelectedItem.ToString().Split('-')[0].Trim();
                var selectedItem = InventoryManager.Inventory.FirstOrDefault(i => i.Name.Equals(selectedItemName, StringComparison.OrdinalIgnoreCase));

                if (selectedItem != null)
                {
                    //add to cart quanity amount of times
                    for(int i=0; i<quantity; i++)
                    {
                        cart.Add(selectedItem);
                    }
                    
                    MessageBox.Show($"{selectedItem.Name} x {quantity} added to cart.");
                    //check if they want more
                    var result = MessageBox.Show("Would you like to add another item?", "Add More Items", MessageBoxButtons.YesNo);
                    DisplayCartItems();
                    //sum total 
                    if (result == DialogResult.No)
                    {
                        CalculateTotal();
                    }
                }
                else
                {
                    MessageBox.Show("Please select an item and enter a valid quantity.");
                }
            }

        }

        private void lstCart_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstCart.Items.Clear();
            foreach(var item in cart)
            {
                lstCart.Items.Add($"{item.Name} - ${item.Price}");
            }
        }
        private void DisplayCartItems()
        {
            lstCart.Items.Clear();

            foreach(var item in cart)
            {
                int quantityInCart = cart.Count(i => i.Name == item.Name);
                decimal totalPrice = item.Price * quantityInCart;

                lstCart.Items.Add($"{item.Name}$ -${item.Price}");

            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            addToCart();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            ReturnToMainMenu();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
