﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignemnt1
{

    public partial class ViewReportForm : Form
    {
        private List<decimal> transactions;

        public ViewReportForm(List<decimal> transactions)
        {
            InitializeComponent();
            this.transactions = transactions;



        }

        private void ViewReport_Load(object sender, EventArgs e)
        {
            if (transactions.Count == 0)
            {
                MessageBox.Show("No Transaction Found");
                this.Close();
                return;
            }
            decimal totalProfit = transactions.Sum();
            int numOfCustomers = transactions.Count();

            MessageBox.Show($"Number of Customers: {numOfCustomers}\n" +
                $"Total Profits: ${totalProfit}");

          
        }

        
    }
}
