﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignemnt1
{
    public partial class MainMenuForm : Form
    {
        
        public MainMenuForm()
        {
            InitializeComponent();
        }

        private void MainMenuForm_Load(object sender, EventArgs e)
        {

        }

        private void btnPurchase_Click(object sender, EventArgs e)
        {
            this.Hide();
            PurchaseForm purchaseForm = new PurchaseForm();
            purchaseForm.ShowDialog();
            this.Show();
        }

        private void btnPurchase_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            ReturnForm returnForm = new ReturnForm();
            returnForm.ShowDialog();
            this.Show();

        }

        private void manageInvBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            ManageInventoryForm manageInventoryForm = new ManageInventoryForm();
            manageInventoryForm.ShowDialog();
            this.Show();


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void reportBtn_Click(object sender, EventArgs e)
        {
            ViewReportForm reportForm = new ViewReportForm(TransactionManager.Transactions);
            reportForm.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
