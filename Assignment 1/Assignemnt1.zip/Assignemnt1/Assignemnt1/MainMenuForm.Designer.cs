﻿
namespace Assignemnt1
{
    partial class MainMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.purchaseBtn = new System.Windows.Forms.Button();
            this.returnBtn = new System.Windows.Forms.Button();
            this.manageInvBtn = new System.Windows.Forms.Button();
            this.reportBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // purchaseBtn
            // 
            this.purchaseBtn.Location = new System.Drawing.Point(206, 83);
            this.purchaseBtn.Name = "purchaseBtn";
            this.purchaseBtn.Size = new System.Drawing.Size(396, 40);
            this.purchaseBtn.TabIndex = 0;
            this.purchaseBtn.Text = "Make a Purchase";
            this.purchaseBtn.UseVisualStyleBackColor = true;
            this.purchaseBtn.Click += new System.EventHandler(this.btnPurchase_Click);
            // 
            // returnBtn
            // 
            this.returnBtn.Location = new System.Drawing.Point(206, 153);
            this.returnBtn.Name = "returnBtn";
            this.returnBtn.Size = new System.Drawing.Size(396, 40);
            this.returnBtn.TabIndex = 1;
            this.returnBtn.Text = "Make a Return";
            this.returnBtn.UseVisualStyleBackColor = true;
            this.returnBtn.Click += new System.EventHandler(this.btnPurchase_Click_1);
            // 
            // manageInvBtn
            // 
            this.manageInvBtn.Location = new System.Drawing.Point(206, 223);
            this.manageInvBtn.Name = "manageInvBtn";
            this.manageInvBtn.Size = new System.Drawing.Size(396, 40);
            this.manageInvBtn.TabIndex = 2;
            this.manageInvBtn.Text = "Manage Inventory";
            this.manageInvBtn.UseVisualStyleBackColor = true;
            this.manageInvBtn.Click += new System.EventHandler(this.manageInvBtn_Click);
            // 
            // reportBtn
            // 
            this.reportBtn.Location = new System.Drawing.Point(206, 293);
            this.reportBtn.Name = "reportBtn";
            this.reportBtn.Size = new System.Drawing.Size(396, 40);
            this.reportBtn.TabIndex = 3;
            this.reportBtn.Text = "View Report";
            this.reportBtn.UseVisualStyleBackColor = true;
            this.reportBtn.Click += new System.EventHandler(this.reportBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(227, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(403, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Welcome To Target! Choose fom the following options:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // MainMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.reportBtn);
            this.Controls.Add(this.manageInvBtn);
            this.Controls.Add(this.returnBtn);
            this.Controls.Add(this.purchaseBtn);
            this.Name = "MainMenuForm";
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.MainMenuForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button purchaseBtn;
        private System.Windows.Forms.Button returnBtn;
        private System.Windows.Forms.Button manageInvBtn;
        private System.Windows.Forms.Button reportBtn;
        private System.Windows.Forms.Label label1;
    }
}