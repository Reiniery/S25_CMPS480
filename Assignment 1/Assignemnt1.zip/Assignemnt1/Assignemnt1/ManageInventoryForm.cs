﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Assignemnt1
{
    public partial class ManageInventoryForm : Form
    {
        public ManageInventoryForm()
        {
            InitializeComponent();
        }

        private void ManageInventoryForm_Load(object sender, EventArgs e)
        {
            DisplayInventory();
        }
        private void DisplayInventory()
        {
            lstInventory.Items.Clear();
            foreach(var item in InventoryManager.Inventory)
            {
                lstInventory.Items.Add($"{item.Name} - ${item.Price}");
            }
        }

        private void lstInventory_MouseClick(object sender, MouseEventArgs e)
        {
            int index = lstInventory.IndexFromPoint(e.Location);

            if (index != ListBox.NoMatches)
            {
                var selectedItem = InventoryManager.Inventory[index];
                //ask for confirmation
                var result = MessageBox.Show($"Are you sure you want to remove {selectedItem.Name}?", "Confirm Delete" ,MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                //remove if yes
                if(result == DialogResult.Yes)
                {
                InventoryManager.Inventory.Remove(selectedItem);
                DisplayInventory();
                MessageBox.Show($"{selectedItem.Name} has been Removed.");
                }
                
            }
        }
       

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            string name = txtItemName.Text.Trim();

            if(!decimal.TryParse(txtItemPrice.Text.Trim(), out decimal price))
            {
                MessageBox.Show("Enter Valid Price");
                return;
            }
            InventoryManager.Inventory.Add(new Item { Name = name, Price = price });
            MessageBox.Show("Item Succesfully Added");

            txtItemName.Clear();
            txtItemPrice.Clear();
            DisplayInventory();
        }

        private void btnRemoveItem_Click(object sender, EventArgs e)
        {
            string nameToRemove = txtRemoveItem.Text.Trim();
            var item = InventoryManager.Inventory
                .FirstOrDefault(i => i.Name.Equals(nameToRemove, StringComparison.OrdinalIgnoreCase));
            if(item!= null)
            {
                InventoryManager.Inventory.Remove(item);
                MessageBox.Show("Item Removed Succesfully");
            }
            else
            {
                MessageBox.Show("Item not found. Try Again");
            }
            txtRemoveItem.Clear();
            DisplayInventory();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstInventory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
