﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignemnt1
{
    public partial class ReturnForm : Form
    {
        public ReturnForm()
        {
            InitializeComponent();
            DisplayAvailableItems();
        }
        private List<Item> cart = new List<Item>();
       
        private void DisplayAvailableItems()
        {
            lstProducts.Items.Clear();
            foreach (var item in InventoryManager.Inventory)
            {
                lstProducts.Items.Add($"{item.Name} - ${item.Price}");
            }
        }
        private void ClearCart()
        {
            cart.Clear();
            lstReturnList.Items.Clear();
        }
        private void ReturnToMainMenu()
        {
            this.Close();
        }
        private void CalculateTotal()
        {
            decimal total = -1*cart.Sum(item => item.Price);
            MessageBox.Show($"Your Refund Total is ${total} \nThank you for shopping at Target! ");

            TransactionManager.Transactions.Add(total);

            ClearCart();
            ReturnToMainMenu();
        }
        private void addToReturnList()
        {
            if (lstProducts.SelectedItem != null && int.TryParse(txtQuantity.Text, out int quantity) && quantity > 0)
            {
                string selectedItemName = lstProducts.SelectedItem.ToString().Split('-')[0].Trim();
                var selectedItem = InventoryManager.Inventory.FirstOrDefault(i => i.Name.Equals(selectedItemName, StringComparison.OrdinalIgnoreCase));

                if (selectedItem != null)
                {
                    //add to cart quanity amount of times
                    for (int i = 0; i < quantity; i++)
                    {
                        cart.Add(selectedItem);
                    }

                    MessageBox.Show($"{selectedItem.Name} x {quantity} added to Return List.");
                    //check if they want more
                    var result = MessageBox.Show("Would you like to add another item?", "Add More Items", MessageBoxButtons.YesNo);
                    DisplayCartItems();
                    //sum total 
                    if (result == DialogResult.No)
                    {
                        CalculateTotal();
                    }
                }
                else
                {
                    MessageBox.Show("Please select an item and enter a valid quantity.");
                }
            }

        }
        private void DisplayCartItems()
        {
            lstReturnList.Items.Clear();

            foreach (var item in cart)
            {
                int quantityInCart = cart.Count(i => i.Name == item.Name);
                decimal totalPrice = item.Price * quantityInCart;

                lstReturnList.Items.Add($"{item.Name}$ -${item.Price}");

            }
        }

        private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ReturnForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAddToRetun_Click(object sender, EventArgs e)
        {
            addToReturnList();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
