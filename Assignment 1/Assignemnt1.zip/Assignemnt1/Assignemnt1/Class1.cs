﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignemnt1
{
    public class Item
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
    public static class InventoryManager
    {
        public static List<Item> Inventory { get; set; } = new List<Item>();
    }

}

