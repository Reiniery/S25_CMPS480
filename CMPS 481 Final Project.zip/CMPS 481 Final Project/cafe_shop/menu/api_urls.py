# menu/api_urls.py
from django.urls import path
from .views import (
    ProductListCreateView,
    ProductUpdateView,
    ProductDeleteView
)

urlpatterns = [
    path('products/', ProductListCreateView.as_view(), name='product-list-create'),
    path('products/<int:pk>/', ProductUpdateView.as_view(), name='product-update'),
    path('products/delete/<int:id>/', ProductDeleteView.as_view(), name='product-delete'),  # 👈 this matches your WPF
]