from django.urls import path
from . import views 
from .views import ProductListCreateView, ProductUpdateView, ProductDeleteView

urlpatterns=[
    path('', views.menu_view, name='menu'),
    path('api/products/', ProductListCreateView.as_view(), name='product-list'),
    path('api/products/<int:pk>/', ProductUpdateView.as_view(), name='product-update'),
    path('api/delete_product/<int:id>',ProductDeleteView.as_view(), name='product-delete')
]