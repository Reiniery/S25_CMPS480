from django.shortcuts import render
from .models import Product
from rest_framework import generics
from .serializers import ProductSerializer
# Create your views here.

def menu_view(request):
    products= Product.objects.filter(available=True)
    return render(request, 'menu/menu.html',{'products':products})
class ProductListCreateView(generics.ListCreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class ProductUpdateView(generics.RetrieveUpdateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class ProductDeleteView(generics.DestroyAPIView):
    queryset = Product.objects.all()
    serializer_class=ProductSerializer
    lookup_field="id"