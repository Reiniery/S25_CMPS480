from django.urls import path
from . import views
from .views import OrderListView, OrderUpdateView


urlpatterns=[
    path('',views.order_view, name='order'),
    path('api/orders/', OrderListView.as_view(), name='order-list'),
    path('orders/<int:pk>/', OrderUpdateView.as_view(), name='order-update')
    
]
