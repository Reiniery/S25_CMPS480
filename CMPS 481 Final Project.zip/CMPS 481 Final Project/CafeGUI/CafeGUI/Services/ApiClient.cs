﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using CafeGUI.Models;
using System.Windows;



namespace CafeGUI.Services
{
    public class ApiClient
    {
        private readonly HttpClient client;

        public ApiClient()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("http://127.0.0.1:8000"); //base url of site
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("Application/json"));

        }
       //GET Products
        public async Task<List<Product>> GetProductsAsync()
            {
            var response = await client.GetAsync("api/products/");
            response.EnsureSuccessStatusCode();
            var json = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<List<Product>>(json);

        }
        //GET Orders
        public async Task<List<Order>> GetOrdersAsync()
        {
            var response = await client.GetAsync("http://127.0.0.1:8000/api/orders/");


            var json = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<List<Order>>(json);
        }
        // PATCH product w id to update if available or not
        public async Task<bool> UpdateProductAvailabilityAsync(int productId, bool available)
        {
            var patchData = new { available = available };
            var content = new StringContent(JsonConvert.SerializeObject(patchData), System.Text.Encoding.UTF8, "application/json");
            var response = await client.PatchAsync($"api/products/{productId}/", content);
            return response.IsSuccessStatusCode;
        }
        // POST Product
        public async Task<bool> AddProductAsync(Product product)
        {
            try
            {
                string json = JsonConvert.SerializeObject(product);

                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PostAsync("api/products/", content);
                return response.IsSuccessStatusCode;

            }
            catch
            {
                return false;
            }
        }
        // PATCH completed order
        public async Task<bool> MarkOrderAsCompletedAsync(int orderId)
        {
            var patchData = new { status = "completed" };
            var content = new StringContent(JsonConvert.SerializeObject(patchData), Encoding.UTF8, "application/json");
            var response = await client.PatchAsync($"api/orders/{orderId}/", content);
            return response.IsSuccessStatusCode;
        }





    }
}
