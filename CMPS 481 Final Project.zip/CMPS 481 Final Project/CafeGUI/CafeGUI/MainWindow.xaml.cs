﻿using System.Collections.ObjectModel;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CafeGUI.Models;
using CafeGUI.Services;
using System.Windows.Threading;

namespace CafeGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer orderRefreshTimer;


        private readonly ApiClient _api = new ApiClient();
        private ObservableCollection<Product> Products = new ObservableCollection<Product>();
        public MainWindow()
        {
            InitializeComponent();
            _= LoadProducts();
            orderRefreshTimer = new DispatcherTimer();
            orderRefreshTimer.Interval = TimeSpan.FromSeconds(5); // reload every 5 seconds
            orderRefreshTimer.Tick += (s, e) =>
            {
                if (OrdersTab.IsSelected)
                {
                    LoadOrderQueue();
                }
            };
            orderRefreshTimer.Start();

        }
        private async Task LoadProducts()
        {
            try
            {
                var productList = await _api.GetProductsAsync();
                Products = new ObservableCollection<Product>(productList);
                ProductGrid.ItemsSource = Products;
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Error loading products: {ex.Message}");
            }
        }
        private async void ToggleAvailability_Click(object sender, RoutedEventArgs e)
        {
            if (ProductGrid.SelectedItem is Product selected)
            {
                bool newStatus = !selected.available;

                bool success = await _api.UpdateProductAvailabilityAsync(selected.id, newStatus);
                if (success)
                {
                    MessageBox.Show($"Product '{selected.name}' availability updated.");
                    await LoadProducts();  // Refresh the list
                }
                else
                {
                    MessageBox.Show("Failed to update availability.");
                }
            }
            else
            {
                MessageBox.Show("Please select a product to toggle availability.");
            }
        }
        private void ProductGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            
            if (e.Column is DataGridCheckBoxColumn)
            {
                
                Dispatcher.BeginInvoke(new Action(async () =>
                {
                    if (ProductGrid.SelectedItem is Product selected)
                    {
                        bool success = await _api.UpdateProductAvailabilityAsync(selected.id, selected.available);
                        if (!success)
                        {
                            MessageBox.Show("Failed to update availability.");
                        }
                    }
                }), System.Windows.Threading.DispatcherPriority.Background);
            }
        }

        private async void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button deleteButton)
            {
                // get the datagrid row from the button contxt

                var product = (Product)deleteButton.DataContext;
                int productId=product.id;


                var result = MessageBox.Show($"Are you sure you want to delete {product.name}?", "Confirm Delete", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes) 
                {
                    bool success = await DeleteProductFromServer(productId);
                    if(success)
                    {
                        //remove from ui
                        Products.Remove(product);
                    }
                    else
                    {
                        MessageBox.Show("Failed To Delete Item.");
                    }
                }

            }
        }


        private async Task<bool> DeleteProductFromServer(int productId)
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.DeleteAsync($"http://127.0.0.1:8000/api/menu/products/delete/{productId}/");
                    return response.IsSuccessStatusCode;
                }
                catch
                {
                    return false;
                }
            }
        }
        private async void UpdateAll_Click(object sender, RoutedEventArgs e)
        {
            if(Products == null || Products.Count == 0)
            {
                MessageBox.Show("No Products to Update");
                return;
            }
            int updated = 0;
            foreach (var product in Products)
            {
                bool success = await _api.UpdateProductAvailabilityAsync(product.id, product.available);
                if (success) {
                    updated++;
                }

            }
            MessageBox.Show($"Updates {updated} out of {Products.Count} products.");
        }
       

        private async void OpenAddProductForm_Click(object sender, EventArgs e)
        {
            var addWindow = new AddProductWindow
            {
                Owner = this
            };
            if (addWindow.ShowDialog() == true)
            {
                var newProduct = addWindow.NewProduct;
                bool success = await _api.AddProductAsync(newProduct);
                if (success)
                {
                    MessageBox.Show("Product Added.");
                    await LoadProducts();
                }
                else
                {
                    MessageBox.Show("Failed to add product");
                }
            }
        }

        private async void LoadOrderQueue()
        {
            try
            {
                var orders = await _api.GetOrdersAsync();
                OrderQueueGrid.ItemsSource = orders;
            }
            catch
            {
                MessageBox.Show("Failed to Load");
            }
        }
        private void OrdersTab_GotFocus(object sender, RoutedEventArgs e)
        {
            LoadOrderQueue();
        }
        private void OrderQueueGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (OrderQueueGrid.SelectedItem is Order selectedOrder)
            {
                ItemGrid.ItemsSource = selectedOrder.items;
            }
            else
            {
                ItemGrid.ItemsSource = null;
            }
        }
        private bool ordersLoaded = false;

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (OrdersTab.IsSelected && !ordersLoaded)
            {
                LoadOrderQueue();
                ordersLoaded = true;
            }
        }

        private async void MarkOrderCompleted_Click(object sender, RoutedEventArgs e)
        {
            if (OrderQueueGrid.SelectedItem is Order selectedOrder)
            {
                bool success = await _api.MarkOrderAsCompletedAsync(selectedOrder.id);
                if (success)
                {
                    MessageBox.Show($"Order #{selectedOrder.id} marked as completed.");
                    LoadOrderQueue(); // refresh queue
                }
                else
                {
                    MessageBox.Show("Failed to update order.");
                }
            }
        }
    }
}