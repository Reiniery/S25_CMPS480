﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CafeGUI.Models;

namespace CafeGUI
{
    /// <summary>
    /// Interaction logic for AddProductWindow.xaml
    /// </summary>
    public partial class AddProductWindow : Window
    {
        public Product NewProduct { get; private set; }
        public AddProductWindow()
        {
            InitializeComponent();
        }
        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrWhiteSpace(NameInput.Text) ||
                CategoryInput.SelectedItem == null ||
                !float.TryParse(PriceInput.Text, out float price)
                )
            {
                MessageBox.Show("Invalid Input");
                return;
            }
            string category = ((ComboBoxItem)CategoryInput.SelectedItem).Content.ToString();
            NewProduct = new Product
            {
                name = NameInput.Text,
                category = category,
                price = (decimal)price,
                available = AvailableInput.IsChecked ?? false,
                description=DescriptionInput.Text
            };

            DialogResult = true;
            Close();
        }
    }
}
