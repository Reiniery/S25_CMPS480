﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using CafeGUI.Models;

namespace CafeGUI.Models
{
    public class Order
    {
        public int id { get; set; }
        public string customer_name { get; set; }
        public string customer_email {  get; set; }
        public string created_at {  get; set; }
        public string status {  get; set; }
        public List<OrderItem> items { get; set; }

    }
    public class OrderItem
    {
        public int id { get; set; }
        public string product_name {  get; set; }
        public int quantity {  get; set; }
    }
}
